document.getElementById('calcular').addEventListener('click', function () {

    const cantidadRetiro = parseInt(document.getElementById('Retiro').value);

    if (Retiro < 0) {
        alert('La cantidad es ivalida debe ingresar una cantidad valida. Por favor, ingrese una cantidad válida.');
        return; 
    }

    const nombreUsuario = document.getElementById('nombreUsuario').value;
    

    document.getElementById("Saludo").textContent = `Bienvenido ${nombreUsuario}, es un gusto tenerte en nuestro banco, tu retiro ha sido ejecutado efectivamente, el retiro es el siguiente :`
    
   
    const billetes100 = Math.floor(cantidadRetiro / 100);
    const billetes50 = Math.floor((cantidadRetiro % 100) / 50);
    const billetes20 = Math.floor(((cantidadRetiro % 100) % 50) / 20);
    const billetes10 = Math.floor((((cantidadRetiro % 100) % 50) % 20) / 10);
    const billetes5 = Math.floor(((((cantidadRetiro % 100) % 50) % 20) % 10) / 5);
    const billetes1 = (((cantidadRetiro % 100) % 50) % 20) % 10 % 5;
    
    document.getElementById('billetes100').textContent = billetes100;
    document.getElementById('billetes50').textContent = billetes50;
    document.getElementById('billetes20').textContent = billetes20;
    document.getElementById('billetes10').textContent = billetes10;
    document.getElementById('billetes5').textContent = billetes5;
    document.getElementById('billetes1').textContent = billetes1;

    
});